self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ee9b19e22f1f92ab0a8d9e85e792c2ef",
    "url": "card/img0.jpg"
  },
  {
    "revision": "293e134a23a408e984ab089532a8fc57",
    "url": "card/img1.jpg"
  },
  {
    "revision": "557004a379432cf82433bb2e758fa64b",
    "url": "card/img2.jpg"
  },
  {
    "revision": "2fcd25596674569f580adad97bb97703",
    "url": "card/img3.jpg"
  },
  {
    "revision": "35e051735129320874bf64467c22e659",
    "url": "card/img4.jpg"
  },
  {
    "revision": "322d78608a850c8b451a74e5f7ab2ec8",
    "url": "card/img5.jpg"
  },
  {
    "revision": "17ea12df31485bd87ca0",
    "url": "css/about.ce436d8f.css"
  },
  {
    "revision": "66c0c368b1e1fc1ae95c",
    "url": "css/app.47cc6efa.css"
  },
  {
    "revision": "25b478aff03688b26c54",
    "url": "css/chunk-28fa4a42.0a9c72f4.css"
  },
  {
    "revision": "409e742860a1843a90fc",
    "url": "css/chunk-5512a8d0.f256e9cc.css"
  },
  {
    "revision": "02f4bac6969dac043643",
    "url": "css/chunk-5a8fe146.20dfec6f.css"
  },
  {
    "revision": "d27115f97de465e4f294",
    "url": "css/chunk-8fcdeba0.f256e9cc.css"
  },
  {
    "revision": "e063f275a24df1630971",
    "url": "css/chunk-b8e471ce.73bb0f89.css"
  },
  {
    "revision": "fdb78f64c7092a8e2334",
    "url": "css/chunk-vendors.3aacdcf0.css"
  },
  {
    "revision": "1151fa2e4f0788a8123fd5d9a7bcc25a",
    "url": "data/card.json"
  },
  {
    "revision": "7025fc404e615d2c6c91b220f721add5",
    "url": "data/room.json"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "ea03ac5167d6522e1ec64bccf58a5174",
    "url": "img/banner.ea03ac51.png"
  },
  {
    "revision": "691c3598f76c4d2d8b510374ca286a5f",
    "url": "img/chat-bot.691c3598.jpg"
  },
  {
    "revision": "d460ec78a37e0ae879693927fec777af",
    "url": "img/robat-head.d460ec78.jpg"
  },
  {
    "revision": "fc9903986fd1827f8b6436e484b02f5a",
    "url": "index.html"
  },
  {
    "revision": "17ea12df31485bd87ca0",
    "url": "js/about.ada3cfde.js"
  },
  {
    "revision": "66c0c368b1e1fc1ae95c",
    "url": "js/app.a6d86669.js"
  },
  {
    "revision": "d83d546fe8c7138fa9e7",
    "url": "js/chunk-06bf9d13.565b11d3.js"
  },
  {
    "revision": "5526dace3d709e67cffdce44af633d9b",
    "url": "js/chunk-06bf9d13.565b11d3.js.LICENSE.txt"
  },
  {
    "revision": "25b478aff03688b26c54",
    "url": "js/chunk-28fa4a42.adb41437.js"
  },
  {
    "revision": "409e742860a1843a90fc",
    "url": "js/chunk-5512a8d0.adbb35c3.js"
  },
  {
    "revision": "02f4bac6969dac043643",
    "url": "js/chunk-5a8fe146.990236fa.js"
  },
  {
    "revision": "d27115f97de465e4f294",
    "url": "js/chunk-8fcdeba0.50113da7.js"
  },
  {
    "revision": "e063f275a24df1630971",
    "url": "js/chunk-b8e471ce.c9d53c36.js"
  },
  {
    "revision": "fdb78f64c7092a8e2334",
    "url": "js/chunk-vendors.41583c4e.js"
  },
  {
    "revision": "8e2605df4720b7ee3a86d7b12ce363ea",
    "url": "js/chunk-vendors.41583c4e.js.LICENSE.txt"
  },
  {
    "revision": "9410948411d656e79bff27baaa054fef",
    "url": "logo.png"
  },
  {
    "revision": "a1464f33a420a7db80c94d9ab4b89827",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "24e7b48ffd9500f03bbe63234bfa11f1",
    "url": "room/back0.jpg"
  },
  {
    "revision": "c466292b91e94f6a9ed0a19794d110d7",
    "url": "room/back1.jpg"
  },
  {
    "revision": "ac357246f20732198fe8d1b3faccbc3f",
    "url": "room/back2.jpg"
  },
  {
    "revision": "d6b41254c2b659c7e6754b03fb474e87",
    "url": "room/back3.jpg"
  },
  {
    "revision": "8beefc1a4db0b5813f03a80410da8ffd",
    "url": "room/back4.jpg"
  },
  {
    "revision": "a5e2b7eea71d3594a6004ccf166c95a7",
    "url": "room/back5.jpg"
  },
  {
    "revision": "a5ff89b900cbf6423ee6416f3ff23232",
    "url": "room/back6.jpg"
  },
  {
    "revision": "c01737062b997930423379aa1947554e",
    "url": "room/back7.jpg"
  },
  {
    "revision": "f8b070b3fe5123088a1411526031c95e",
    "url": "user/head0.jpg"
  },
  {
    "revision": "e1e8fed006bdfc5705589fe1308e8daa",
    "url": "user/head1.jpg"
  },
  {
    "revision": "4016089928f505294054bf9172b517ea",
    "url": "user/head2.jpg"
  },
  {
    "revision": "72fba0c5c2753a541424b5a6f8abc003",
    "url": "user/head3.jpg"
  },
  {
    "revision": "484c61b0d47787c6a0133980ca03218a",
    "url": "user/head4.jpg"
  },
  {
    "revision": "7789564f9ee961345b545f88cacae7e7",
    "url": "user/head5.jpg"
  }
]);